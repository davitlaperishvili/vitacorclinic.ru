<?php

namespace WP_Rocket\Engine\Container;

use Psr\Container\ContainerInterface as InteropContainerInterface;

interface ImmutableContainerInterface extends InteropContainerInterface
{

}
